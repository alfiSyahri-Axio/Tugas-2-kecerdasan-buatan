%SILSILAH KELUARGA GARIS(IBU)
%FAKTA JENIS KELAMIN
laki(uddin).            % kakek
laki(saparuddin).       % ayah
laki(amrin).            % paman
laki(muhammad_aspar).   % anak pertama
laki(muhammad_aswar).   % anak kedua
laki(alfi_syahri).      % anak ketiga (Aku)

perempuan(bau_alang).   % nenek
perempuan(nur_alang).   % bibi
perempuan(satu_alang).  % bibi
perempuan(tani_alang).  % ibu

%FAKTA orangtua(OrangTua,Anak)
orangtua(uddin, amrin).
orangtua(uddin, nur_alang).
orangtua(uddin, satu_alang).
orangtua(uddin, tani_alang).
orangtua(bau_alang, amrin).
orangtua(bau_alang, nur_alang).
orangtua(bau_alang, satu_alang).
orangtua(bau_alang, tani_alang).

orangtua(saparuddin, muhammad_aspar).
orangtua(saparuddin, muhammad_aswar).
orangtua(saparuddin, alfi_syahri).
orangtua(tani_alang, muhammad_aspar).
orangtua(tani_alang, muhammad_aswar).
orangtua(tani_alang, alfi_syahri).
%Query untuk mencari anggota keluarga dalam silsilah

%Ayah / Ibu
ayah(Ayah, Anak) :- orangtua(Ayah, Anak), laki(Ayah).
ibu(Ibu, Anak)   :- orangtua(Ibu, Anak), perempuan(Ibu).

% Anak = kebalikan dari orangtua/2
anak(Anak, OrangTua) :- orangtua(OrangTua, Anak).

% Kakek / Nenek (orangtua dari orangtua)
kakek(Kakek, Cucu) :-
    orangtua(Kakek, OrgTua),
    orangtua(OrgTua, Cucu),
    laki(Kakek).

nenek(Nenek, Cucu) :-
    orangtua(Nenek, OrgTua),
    orangtua(OrgTua, Cucu),
    perempuan(Nenek).

% Cucu = kebalikan dari kakek/nenek
cucu(Cucu, KakekNenek) :- kakek(KakekNenek, Cucu).
cucu(Cucu, KakekNenek) :- nenek(KakekNenek, Cucu).

% Saudara kandung: berbagi ayah YANG SAMA dan ibu YANG SAMA
saudara_kandung(X, Y) :-
    orangtua(Ayah, X), orangtua(Ayah, Y), laki(Ayah),
    orangtua(Ibu, X),  orangtua(Ibu, Y),  perempuan(Ibu),
    X \= Y.

saudara_laki(S, X)      :- saudara_kandung(S, X), laki(S).
saudara_perempuan(S, X) :- saudara_kandung(S, X), perempuan(S).

% Paman: saudara laki-laki dari salah satu orangtua
paman(Paman, Keponakan) :-
    orangtua(OrgTua, Keponakan),
    saudara_laki(Paman, OrgTua).

% Bibi: saudara perempuan dari salah satu orangtua
bibi(Bibi, Keponakan) :-
    orangtua(OrgTua, Keponakan),
    saudara_perempuan(Bibi, OrgTua).

% Keturunan (turunan ke bawah, transitif)
keturunan(X, Y) :- orangtua(Y, X).
keturunan(X, Y) :- orangtua(Z, X), keturunan(Z, Y).

% Leluhur (garis ke atas, transitif) = kebalikan keturunan
leluhur(X, Y) :- keturunan(Y, X).
